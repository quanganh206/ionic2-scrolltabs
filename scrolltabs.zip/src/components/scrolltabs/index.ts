export { ScrollTabsComponent } from './scrolltabs';
export { IScrollTab } from './scrolltab';