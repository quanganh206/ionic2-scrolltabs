export interface IScrollTab {
    name: string;
    selected?: boolean;
}